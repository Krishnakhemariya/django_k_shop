from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from store.models.customers import Customers
from django.views import View


class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        a = request.POST
        first_name = a.get("first_name")
        last_name = a.get('last_name')
        phone_num = a.get('phone_num')
        email = a.get('email')
        password = a.get('password')
        # validation
        value = {'first_name': first_name,
                 'last_name': last_name,
                 'phone_num': phone_num,
                 'email': email}
        error_msg = None
        customers = Customers(first_name=first_name,
                              last_name=last_name,
                              phone_num=phone_num,
                              email=email,
                              password=password)

        error_msg = self.validateuser(customers)
        # saving
        if (not error_msg):
            print(first_name, last_name, phone_num, email, password)
            customers.password = make_password(customers.password)

            customers.register()
            return redirect('homepage')

        else:
            data = {
                'error': error_msg,
                'values': value
            }
            return render(request, 'signup.html', data)

    def validateuser(self, customers):
        error_msg = None;
        if (not customers.first_name):
            error_msg = "please enter first name "

        elif (len(customers.first_name)) < 4:
            error_msg = "please write long"

        elif (not customers.last_name):
            error_msg = "please enter last name "

        elif (len(customers.last_name)) < 4:
            error_msg = "please write long lats"

        elif (not customers.phone_num):
            error_msg = "please enter phone number "
        elif (len(customers.phone_num)) < 10:
            error_msg = "please write long phone number"

        elif (not customers.email):
            error_msg = "please enter email "

        elif (len(customers.email)) < 4:
            error_msg = "please write long email"

        elif customers.isexist():
            error_msg = "customer already exist....."

        return error_msg
