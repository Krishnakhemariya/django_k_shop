from django.contrib import admin
from .models.product import Product
from .models.category import Category
from .models.customers import Customers

class adminproduct(admin.ModelAdmin):
    list_display = ["name","price","category","discription"]
class admincategory(admin.ModelAdmin):
    list_display = ["name"]

# Register your models here.
admin.site.register(Product,adminproduct)
admin.site.register(Category,admincategory)
admin.site.register(Customers)